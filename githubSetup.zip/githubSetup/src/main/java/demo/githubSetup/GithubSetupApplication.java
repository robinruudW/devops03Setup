package demo.githubSetup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GithubSetupApplication {

	public static void main(String[] args) {
		SpringApplication.run(GithubSetupApplication.class, args);
	}

}
